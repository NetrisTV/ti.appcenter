#import <Foundation/Foundation.h>

@interface MSAbstractLog : NSObject

@end
