#import <Foundation/Foundation.h>

#import "MSAbstractLog.h"

@interface MSLogWithProperties : MSAbstractLog

@end
